# Wine Dataset
1. You need to download “Wine” data from the kaggle; ref is given below.
2. Follow assignment-1 steps 2 to 5 to perform data processing and write inferences.
3. Perform at least 5 Clustering methods with varying cluster sizes. Find correct cluster numbers for each method and show with line plot, 
how you finalized this cluster number.
4. Compare all the clustering methods and write how you compared what method you used and why?
5. Do steps 3 and 4 again after dimension reduction, and show whether it is helpful; if not why?

Ref: https://www.kaggle.com/harrywang/wine-dataset-for-clustering
